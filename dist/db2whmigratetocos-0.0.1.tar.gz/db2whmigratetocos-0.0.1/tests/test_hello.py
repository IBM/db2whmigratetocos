from db2whmigratetocos.db2wh_db2_utilities import get_connection_string
import unittest

if __name__ == "__main__":
    unittest.main()

